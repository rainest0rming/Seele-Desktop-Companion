--Readme--

Welcome to the Seele Vollerei Desktop Companion.
This was originally made for a friend of mine :)

She contains a bit of dialogue and some secret stuff.
Please report any bugs to the github page, or dm Ray on discord (rainestorm#0578)

I hope you enjoy!